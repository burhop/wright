# Robot arm media · unpublished draft captions

Saved prompt-to-CAD process evidence plus supplemental exact-geometry native renderings and export/reserve checks. Native renderings are not yet bound into the main saved process. No physical testing or engineering acceptance.

Suggested carousel: 07 (hero) → 14 (Wright process) → 16 (geometry) → 17 (fit) → 18 (STLs) → 20 (open findings).

## 01 · SteveCAD · isometric
File: `images/01-stevecad-isometric.png`
Type: Native SteveCAD MCP image

Revision 7 in SteveCAD, isometric view. Actual CAD geometry; dimensions are verified from measurements, not pixels.

## 02 · SteveCAD · top
File: `images/02-stevecad-top.png`
Type: Native SteveCAD MCP image

Revision 7 in SteveCAD, top view. Actual CAD geometry; dimensions are verified from measurements, not pixels.

## 03 · SteveCAD · front
File: `images/03-stevecad-front.png`
Type: Native SteveCAD MCP image

Revision 7 in SteveCAD, front view. Actual CAD geometry; dimensions are verified from measurements, not pixels.

## 04 · SteveCAD · right side
File: `images/04-stevecad-right.png`
Type: Native SteveCAD MCP image

Actual revision-7 SteveCAD geometry. Digital prototype; physical assembly and operation remain untested.

## 05 · SteveCAD · gripper detail
File: `images/05-stevecad-gripper.png`
Type: Native SteveCAD MCP image

Actual revision-7 SteveCAD geometry. Digital prototype; physical assembly and operation remain untested.

## 06 · SteveCAD · electronics bay
File: `images/06-stevecad-electronics.png`
Type: Native SteveCAD MCP image

Actual revision-7 SteveCAD geometry. Simplified official CM5 IO Board and CM5 clearance references; connectors, cooler and cables require further checking.

## 07 · Studio rendering · isometric
File: `images/07-render-isometric.png`
Type: Native Blender rendering of checked STEP meshes

From prompt to an articulated robot-arm concept. Native Blender rendering of the exact revision-7 exported geometry; lighting and materials are presentation, not dimensional evidence.

## 08 · Studio rendering · top
File: `images/08-render-top.png`
Type: Native Blender rendering of checked STEP meshes

From prompt to an articulated robot-arm concept. Native Blender rendering of the exact revision-7 exported geometry; lighting and materials are presentation, not dimensional evidence.

## 09 · Studio rendering · front
File: `images/09-render-front.png`
Type: Native Blender rendering of checked STEP meshes

From prompt to an articulated robot-arm concept. Native Blender rendering of the exact revision-7 exported geometry; lighting and materials are presentation, not dimensional evidence.

## 10 · CAD pose · home
File: `images/10-pose-home.png`
Type: Neutral CAD viewer using actual STEP triangles and native joints

Actual CAD geometry in the home pose. Playback follows saved native joint definitions; it is not footage of a physical robot.

## 11 · CAD pose · reach
File: `images/11-pose-reach.png`
Type: Neutral CAD viewer using actual STEP triangles and native joints

Actual CAD geometry in the reach pose. Playback follows saved native joint definitions; it is not footage of a physical robot.

## 12 · CAD pose · folded
File: `images/12-pose-folded.png`
Type: Neutral CAD viewer using actual STEP triangles and native joints

Actual CAD geometry in the folded pose. Playback follows saved native joint definitions; it is not footage of a physical robot.

## 13 · CAD pose · gripper open
File: `images/13-pose-gripper_open.png`
Type: Neutral CAD viewer using actual STEP triangles and native joints

Actual CAD geometry in the gripper open pose. Playback follows saved native joint definitions; it is not footage of a physical robot.

## 14 · Wright · connected design process
File: `images/14-wright-process.png`
Type: Actual Wright workspace screenshot

Wright coordinates a saved design process and preserves its run outputs. A completed run is distinct from engineering acceptance; the original review retains FAIL and UNVERIFIED findings.

## 15 · Wright · completed run and results
File: `images/15-wright-results.png`
Type: Actual Wright workspace screenshot

Wright coordinates a saved design process and preserves its run outputs. A completed run is distinct from engineering acceptance; the original review retains FAIL and UNVERIFIED findings.

## 16 · Check the actual geometry
File: `images/16-validation-geometry.png`
Type: Evidence graphic derived from saved results; not a Wright UI screenshot

What is actually in the CAD? 110 valid solids, measured 100/90 mm arm links and a derived 0.20 mm pivot radial gap. Wright retains the exact design-revision evidence. Physical strength and post-print fit still need testing.

## 17 · Check fit and sampled motion
File: `images/17-validation-fit.png`
Type: Evidence graphic derived from saved results; not a Wright UI screenshot

Five named fit states, 5,995 pairs each; 33 samples on the saved digital motion path. No new path collisions reported. Continuous clearance and the required minimum distance at every sample remain unverified.

## 18 · Verify the exported print files
File: `images/18-validation-print-files.png`
Type: Evidence graphic derived from saved results; not a Wright UI screenshot

18 oriented STL files for 28 printed pieces. Mesh closure, connectivity, winding, hashes and build-volume bounds checked against the exact CAD. Export integrity passes; supports, slicing and physical prints still need validation.

## 19 · Check the electronics reserve
File: `images/19-validation-electronics.png`
Type: Evidence graphic derived from saved results; not a Wright UI screenshot

The robot concept reserves space for a CM5 IO Board: five poses and 33 path states clear the declared electronics headroom by conservative bounds. Real connectors, cooling, cables and continuous motion still need engineering checks.

## 20 · Keep the unresolved findings visible
File: `images/20-validation-review.png`
Type: Evidence graphic derived from saved results; not a Wright UI screenshot

Engineering review means keeping the gaps visible. The original 16-test register retains 10 PASS, 4 UNVERIFIED and 2 FAIL results. Supplemental checks add evidence without rewriting those findings or granting acceptance.

## Orbit video
12-second 360° camera orbit of the actual revision-7 robot CAD. Neutral viewer; this is a digital prototype, not a physical robot or new clearance simulation.

## Joint-motion video
8-second playback using the actual exported triangles and recorded native joint definitions. Sampled native collision results have bounded coverage; physical operation remains untested.

## Posting notes
Lead with the studio render or orbit; follow with the evidence graphics. Native SteveCAD MCP images are not Studio browser screenshots. Report graphics are not Wright UI screenshots. Do not imply motor selection, print readiness, payload performance or engineering acceptance. No upload or posting has been performed.
