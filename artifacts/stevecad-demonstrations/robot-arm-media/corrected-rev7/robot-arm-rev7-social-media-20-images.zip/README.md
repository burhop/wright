# Wright robot-arm media · unpublished

Open `index.html` for the gallery and videos. Open `contact-sheet.png` for a quick overview. All 20 numbered originals are in `images/`; their labels, captions, sources and hashes are in `manifest.json` and `captions.md`.

The two MP4 videos are H.264 High / yuv420p with silent AAC audio, 1280 × 720 at 24 fps and fast-start. The 12-second video rotates the camera through 360 degrees; the 8-second video follows saved native joint motion. Both use the exact exported revision-7 CAD triangles in a neutral Three.js viewer. Neither is a SteveCAD Studio screen recording or physical robot footage.

Images 01–06 are native SteveCAD MCP images. 07–09 are final native Blender renderings of the same checked geometry. 10–13 are neutral-viewer saved poses. 14–15 are actual Wright workspace screenshots. 16–20 are clearly labeled evidence graphics, not application screenshots. Their HTML sources are included under `reports/`.

The saved prompt-to-CAD run is distinct from supplemental native rendering and export/reserve checks; the final native renderer is not yet bound into the main saved workflow. The original validation register contains 10 PASS, 4 UNVERIFIED and 2 FAIL results, with deferred checks separate. Full engineering acceptance remains open. Physical printing, supports, slicing, assembly, strength, torque, stability and powered operation have not been tested. MG996R × 3 / MG90S × 2 remain provisional hardware references. Actual CM5 IO Board connectors, cables and cooling need further checking.

`evidence/` includes retained numeric results, the original generated design document and preconstruction test plan, provenance, and the successful read-only UI capture status. Paths in the provenance identify the original Wright workspace artifacts; the portable gallery uses only files within this package. A subsequent larger UI capture stopped at editor entry and is retained in the workspace, not substituted for the successful screenshots.

No upload, social-media posting or publication has been performed. Suggested first carousel: 07 → 14 → 16 → 17 → 18 → 20. Use the saved captions and keep the scope statements with engineering claims.
